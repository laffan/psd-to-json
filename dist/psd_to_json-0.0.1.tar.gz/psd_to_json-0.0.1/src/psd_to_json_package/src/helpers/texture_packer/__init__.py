""" src/helpers/texture_packer/__init__.py
Initializes the texture packer module.

This module provides functionality for efficiently packing multiple
smaller images into a single larger image (texture atlas).
"""